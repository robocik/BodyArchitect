using System;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;

namespace Visiblox.Charts.Examples.Internationalization
{
    public partial class InternationalizationExample : UserControl
    {
        private static Culture defaultCulture = new Culture { Description = "British English", Name = "en-GB", YAxisLabel = "Price", ChartTitle = "Exchange Rate (GBP/JPY)" };

        private Dictionary<string, Culture> cultures = new Dictionary<string, Culture>();

        public InternationalizationExample()
        {
            InitializeComponent();

            // Define data series
            var lineSeries = new LineSeries();
            lineSeries.DataSeries = GenerateDataSeries();
            lineSeries.LineStrokeThickness = 1.5;
            Chart.Series.Add(lineSeries);

            // Define culture entries for the combo box
            cultures.Add("British English", defaultCulture);
            cultures.Add("Czech", new Culture { Description = "Czech", Name = "cs-CZ", YAxisLabel = "Cena", ChartTitle = "Kurz (GBP/JPY)" });
            cultures.Add("Hungarian", new Culture { Description = "Hungarian", Name = "hu-HU", YAxisLabel = "Ár", ChartTitle = "Árfolyam (GBP/JPY)" });
            cultures.Add("French", new Culture { Description = "French", Name = "fr-FR", YAxisLabel = "Prix", ChartTitle = "Taux de change (GBP/JPY)" });
            cultures.Add("Russian", new Culture { Description = "Russian", Name = "ru-RU", YAxisLabel = "Цена", ChartTitle = "Обмен валюты (GBP/JPY)" });

            SetCulture(defaultCulture);
        }

        private IDataSeries GenerateDataSeries()
        {
            var series = new DataSeries<DateTime, double>();

            //open stream of data file
            using (StreamReader streamReader = new StreamReader(ExampleHelpers.GetApplicationResourceStream("Internationalization/Data/gbpjpy.csv").Stream))
            {
                // Read through the csv file and fill up dataSeries with the data
                {
                    streamReader.ReadLine();
                    while (streamReader.Peek() >= 0)
                    {
                        string line = streamReader.ReadLine();
                        string[] values = line.Split(',');

                        String[] dateParts = values[0].Split('/');
                        DateTime date = new DateTime(int.Parse(dateParts[2]), int.Parse(dateParts[0]), int.Parse(dateParts[1]));
                        double price = double.Parse(values[1]);

                        series.Add(new DataPoint<DateTime, double>(date, price));
                    }
                }
            }

            return series;
        }

        private void Culture_CheckChanged(object sender, RoutedEventArgs e)
        {
            var button = sender as RadioButton;

            if (button != null && Chart != null)
            {
                var selectedCulture = button.Tag == null ? defaultCulture : cultures[button.Tag.ToString()];
                SetCulture(selectedCulture);
            }
        }

        private void SetCulture(Culture culture)
        {
            try
            {
                Chart.YAxis.Title = culture.YAxisLabel;
                Chart.XAxis.Title = culture.XAxisLabel;
                Chart.Title = culture.ChartTitle;
                Chart.XAxis.LabelFormatString = culture.LongDatePattern;

                ErrorMessagePanel.Visibility = Visibility.Collapsed;
                Thread.CurrentThread.CurrentCulture = new CultureInfo(culture.Name);
                Chart.Invalidate();
            }
            catch (ArgumentException)
            {
                ErrorMessagePanel.Visibility = Visibility.Visible;
            }
        }

        // Data Model

        /// <summary>
        /// Class to store cultures to use on chart
        /// </summary>
        public class Culture
        {
            public string Name { get; set; }

            public string Description { get; set; }

            public string YAxisLabel { get; set; }

            public string XAxisLabel { get; set; }

            public string ChartTitle { get; set; }

            public string LongDatePattern
            {
                get { return new CultureInfo(Name).DateTimeFormat.LongDatePattern; }
            }

            public override string ToString()
            {
                return Description;
            }
        }
    }
}