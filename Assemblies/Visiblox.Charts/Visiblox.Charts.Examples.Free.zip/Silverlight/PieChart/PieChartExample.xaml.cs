using System.Windows.Controls;
using System.Windows;
using System;

namespace Visiblox.Charts.Examples.PieChart
{
    /// <summary>
    /// A simple pie chart example showing a few categories of data
    /// </summary>
    public partial class PieChartExample : UserControl
    {
        public PieChartExample()
        {
            InitializeComponent();
            MainChart.DataSeries = GenerateDataSeries();
        }

        private IDataSeries GenerateDataSeries()
        {
            var series = new DataSeries<string, double>();

            series.Add(new DataPoint<string, double>("F. Alonso", 5));
            series.Add(new DataPoint<string, double>("J. Button", 2));
            series.Add(new DataPoint<string, double>("L. Hamilton", 3));
            series.Add(new DataPoint<string, double>("S. Vettel", 5));
            series.Add(new DataPoint<string, double>("M. Webber", 4));

            return series;
        }

        private void CheckBox_Clicked(object sender, RoutedEventArgs e)
        {
            if (MainChart != null)
            {
                var button = sender as CheckBox;

                if (button.Tag != null)
                {
                    switch (button.Tag.ToString())
                    {
                        case "Bevel":
                            EnableBevel(button.IsChecked == true);
                            break;
                        case "Animation":
                            EnableAnimation(button.IsChecked == true);
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        private void EnableAnimation(bool value)
        {
            MainChart.AnimationEnabled = value;
        }

        private void EnableBevel(bool value)
        {
            MainChart.BevelDepth = value ? 10 : 0;
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (MainChart != null)
            {
                MainChart.BevelDepth = e.NewValue;
            }
        }
    }
}
