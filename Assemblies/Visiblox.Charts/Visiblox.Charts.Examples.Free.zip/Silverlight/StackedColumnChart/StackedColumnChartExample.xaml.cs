using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Visiblox.Charts.Examples.StackedColumnChart
{
    /// <summary>
    /// An example displaying stacked column charts
    /// </summary>
    public partial class StackedColumnChartExample : UserControl
    {
        public StackedColumnChartExample()
        {
            InitializeComponent();
        }

        private void Stacked_Checked(object sender, RoutedEventArgs e)
        {
            if (MainChart == null)
                return;

            var series = MainChart.Series.First() as StackedColumnSeries;
            series.StackingMode = StackingMode.Normal;

            MainChart.YAxis.Title = "Votes (millions)";
        }

        private void OneHundredStacked_Checked(object sender, RoutedEventArgs e)
        {
            if (MainChart == null)
                return;

            var series = MainChart.Series.First() as StackedColumnSeries;
            series.StackingMode = StackingMode.HundredPercent;

            MainChart.YAxis.Title = "Vote Share (%)";
        }
    }

    // Data Model

    public class PartyList : List<ElectionResult> { }

    public class ElectionResult
    {
        public String Year { get; set; }

        public double VotesMillions { get; set; }
    }
}
