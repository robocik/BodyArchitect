using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Input;

namespace Visiblox.Charts.Examples.ColumnChart
{
    /// <summary>
    /// A simple chart example displaying column charts
    /// </summary>
    public partial class ColumnChartExample : UserControl
    {
        public ColumnChartExample()
        {
            InitializeComponent();

            //Set HighlightedStyle to Normal style and add mouse enter and leave events on series
            foreach (ColumnSeries series in MainChart.Series)
            {
                series.MouseEnter += new MouseEventHandler(series_MouseEnter);
                series.MouseLeave += new MouseEventHandler(series_MouseLeave);
            }
        }

        /// <summary>
        /// Mouse has entered one of the bar datapoints - set cursor to hand
        /// </summary>
        void series_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        /// <summary>
        /// Mouse has left one of the bar datapoints - set cursor to arrow
        /// </summary>
        void series_MouseLeave(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Arrow;
        }
    }

    // Data model

    /// <summary>
    /// A list of debt levels
    /// </summary>
    public class GDPDataPointList : List<GDPDataPoint> { }

    /// <summary>
    /// A debt level object
    /// </summary>
    public class GDPDataPoint
    {
        /// <summary>
        /// The year, as a string, that this GDP data point aligns to
        /// </summary>
        public string Date { get; set; }

        /// <summary>
        /// The GDP value for this date
        /// </summary>
        public double GDP { get; set; }
    }
}