using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Resources;
using System.Windows;

namespace Visiblox.Charts.Examples
{
    public static class ExampleHelpers
    {
        public static StreamResourceInfo GetApplicationResourceStream(string resource)
        {
            return Application.GetResourceStream(new Uri(resource, UriKind.Relative));
        }
    }
}
