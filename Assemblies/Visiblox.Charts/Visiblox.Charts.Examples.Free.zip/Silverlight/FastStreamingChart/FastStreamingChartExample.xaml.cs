using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Visiblox.Charts.Examples.FastStreamingChart
{
    /// <summary>
    /// An example to display a chart streaming data quickly
    /// </summary>
    public partial class FastStreamingChartExample : UserControl
    {
        private Random random = new Random(20110810);

        /// <summary>
        /// The current date and time that is plotted at the moment
        /// </summary>
        private DateTime currentTime;

        /// <summary>
        /// Maximum points to display on the charts
        /// </summary>
        private const int MaxPoints = 80;

        /// <summary>
        /// Time between updates (in ms)
        /// </summary>
        private int tickInterval = 250;

        private DateTime lastUpdated;

        public FastStreamingChartExample()
        {
            InitializeComponent();

            // Add zooming to the chart by setting its behavour to ZoomBehaviour
            chart.Behaviour = new ZoomBehaviour();

            chart.Series.First().DataSeries = GenerateDataSeries();

            CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);
        }

        private IDataSeries GenerateDataSeries()
        {
            var data = new DataSeries<DateTime, double>();

            // Set the starting date a year earlier & set initial price
            this.currentTime = DateTime.Now.AddYears(-1);
            double price = 25.00;

            // Create initial data for the charts and assign it to them
            for (int i = 0; i < 100; i++)
            {
                currentTime = currentTime.AddMinutes(1);

                // Generate the price
                price += random.NextDouble() - 0.5;
                data.Add(new DataPoint<DateTime, double>(currentTime, price));
            }

            return data;
        }

        private void SpeedControl_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            tickInterval = (int)e.NewValue;
        }

        void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            if ((DateTime.Now - lastUpdated).TotalMilliseconds > tickInterval)
            {
                UpdateChart();
            }
        }

        /// <summary>
        /// Updates the charts
        /// </summary>
        void UpdateChart()
        {
            if (((FrameworkElement)chart.Parent).ActualWidth == 0)
                return;

            // Generate the current price based on the previous price and update the data source of the price series
            // The price chart is automatically updated because its DataSeries property implements INotifyCollectionChanged
            var priceData = (DataSeries<DateTime, double>)chart.Series[0].DataSeries;

            double currentPrice = priceData[priceData.Count - 1].Y + random.NextDouble() - 0.5;
            priceData.Add(new DataPoint<DateTime, double>(currentTime, currentPrice));

            currentTime = currentTime.AddMinutes(1);

            if (priceData.Count > MaxPoints)
            {
                priceData.RemoveAt(0);
            }

            lastUpdated = DateTime.Now;
        }
    }
}
