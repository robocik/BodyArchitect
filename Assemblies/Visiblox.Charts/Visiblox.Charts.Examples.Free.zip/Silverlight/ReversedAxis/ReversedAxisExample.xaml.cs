using System;
using System.IO;
using System.Windows.Controls;

namespace Visiblox.Charts.Examples.ReversedAxis
{
    public partial class ReversedAxisExample : UserControl
    {
        private string torqueovertimefile = "torqueovertime.csv";
        private string rpmovertimefile = "rpmovertime.csv";
        private string torquebydepthfile = "torquebydepth.csv";
        private string rpmbydepthfile = "rpmbydepth.csv";

        public ReversedAxisExample()
        {
            InitializeComponent();

            TimeChart.Series[0].DataSeries = GenerateTimeDataSeries(torqueovertimefile);
            TimeChart.Series[1].DataSeries = GenerateTimeDataSeries(rpmovertimefile);

            TimeChart.Series[0].XAxis = TimeChart.SecondaryXAxis;
            TimeChart.Series[1].XAxis = TimeChart.AdditionalSecondaryXAxes[0];

            DepthChart.Series[0].DataSeries = GenerateDepthDataSeries(torquebydepthfile);
            DepthChart.Series[1].DataSeries = GenerateDepthDataSeries(rpmbydepthfile);

            DepthChart.Series[0].XAxis = DepthChart.SecondaryXAxis;
            DepthChart.Series[1].XAxis = DepthChart.AdditionalSecondaryXAxes[0];
            DepthChart.Series[0].YAxis = DepthChart.SecondaryYAxis;
            DepthChart.Series[1].YAxis = DepthChart.SecondaryYAxis;

            TimeChart.YAxis.Zoom = DepthChart.SecondaryYAxis.Zoom;
        }

        private IDataSeries GenerateTimeDataSeries(string filename)
        {
            //Create a data series with the appropriate name
            var series = new DataSeries<double, DateTime>();

            using (StreamReader streamReader = new StreamReader(ExampleHelpers.GetApplicationResourceStream("ReversedAxis/Data/" + filename).Stream))
            {
                while (streamReader.Peek() >= 0)
                {
                    string line = streamReader.ReadLine();
                    string[] parts = line.Split(',');

                    //the files are formatted like so: "value,DD/MM/YYYY HH:mm"
                    double val = double.Parse(parts[0]);

                    String[] dateTimeParts = parts[1].Split(' ');
                    String[] dateParts = dateTimeParts[0].Split('/');
                    String[] timeParts = dateTimeParts[1].Split(':');
                    DateTime time = new DateTime(int.Parse(dateParts[2]), int.Parse(dateParts[0]), int.Parse(dateParts[1]), int.Parse(timeParts[0]), int.Parse(timeParts[1]), 0);

                    series.Add(new DataPoint<double, DateTime>(val, time));
                }

            }

            return series;
        }

        private IDataSeries GenerateDepthDataSeries(string filename)
        {
            //Create a data series with the appropriate name
            var series = new DataSeries<double, double>();

            using (StreamReader streamReader = new StreamReader(ExampleHelpers.GetApplicationResourceStream("ReversedAxis/Data/" + filename).Stream))
            {
                while (streamReader.Peek() >= 0)
                {
                    string line = streamReader.ReadLine();
                    string[] parts = line.Split(',');

                    //the files are formatted like so: "value, depth"
                    double val = double.Parse(parts[0]);
                    double depth = double.Parse(parts[1]);

                    series.Add(new DataPoint<double, double>(val, depth));
                }

            }

            return series;
        }
    }
}
