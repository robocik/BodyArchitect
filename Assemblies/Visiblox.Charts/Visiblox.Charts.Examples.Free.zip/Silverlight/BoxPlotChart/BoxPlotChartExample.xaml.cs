﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;

namespace Visiblox.Charts.Examples.BoxPlotChart
{
    /// <summary>
    /// An example chart using a box plot series.
    /// </summary>
    public partial class BoxPlotChartExample : UserControl
    {
        public BoxPlotChartExample()
        {
            InitializeComponent();
            chart.Series[0].DataSeries = GenereateDataSeries();
        }

        /// <summary>
        /// Generates the data series for the example.
        /// </summary>
        /// <returns>The data series containing information about train delays</returns>
        private IDataSeries GenereateDataSeries()
        {
            var dataSeries = new DataSeries<DateTime, double>();
            
            DateTime date = new DateTime(2011,07,01);

            using (StreamReader reader = new StreamReader(ExampleHelpers.GetApplicationResourceStream("BoxPlotChart/Data/train_data.csv").Stream))
            {
                // first line is header information so skip over it
                reader.ReadLine();

                while(reader.Peek() >= 0)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(',');

                    // Create the data for the current date
                    Dictionary<object, double> dayData = new Dictionary<object, double>()
                    {
                        { BoxPlotSeries.Minimum, Double.Parse(values[0]) },
                        { BoxPlotSeries.LowerQuartile, Double.Parse(values[1]) },
                        { BoxPlotSeries.Median, Double.Parse(values[2]) },
                        { BoxPlotSeries.UpperQuartile, Double.Parse(values[3]) },
                        { BoxPlotSeries.Maximum, Double.Parse(values[4]) }
                    };

                    dataSeries.Add(new MultiValuedDataPoint<DateTime, double>(date.Date, dayData));
                    
                    date = date.AddDays(1);
                }
            }

            return dataSeries;
        }
    }
}
