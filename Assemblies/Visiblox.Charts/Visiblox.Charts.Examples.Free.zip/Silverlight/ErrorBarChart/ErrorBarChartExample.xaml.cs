﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace Visiblox.Charts.Examples.ErrorBarChart
{
    /// <summary>
    /// An example chart using Error Bar Series
    /// </summary>
    public partial class ErrorBarChartExample : UserControl
    {
        private Random _random;

        public ErrorBarChartExample()
        {
            InitializeComponent();
            _random = new Random(20111130);

            IDataSeries twoHundredDataSeries;
            IDataSeries twoHundredErrorSeries;
            IDataSeries oneHundredDataSeries;
            IDataSeries oneHundredErrorSeries;
            IDataSeries fiftyDataSeries;
            IDataSeries fiftyErrorSeries;

            GenerateDataSeries(200, out twoHundredDataSeries, out twoHundredErrorSeries);
            GenerateDataSeries(100, out oneHundredDataSeries, out oneHundredErrorSeries);
            GenerateDataSeries(50, out fiftyDataSeries, out fiftyErrorSeries);

            chart.Series[0].DataSeries = twoHundredErrorSeries;
            chart.Series[1].DataSeries = twoHundredDataSeries;
            chart.Series[2].DataSeries = oneHundredErrorSeries;
            chart.Series[3].DataSeries = oneHundredDataSeries;
            chart.Series[4].DataSeries = fiftyErrorSeries;
            chart.Series[5].DataSeries = fiftyDataSeries;
        }

        /// <summary>
        /// Generates a date series and an error bar series displaying the mean of a set
        /// of randomly generated values between 0 and <paramref name="maxValue"/> and the
        /// standard error of the mean.
        /// </summary>
        /// <param name="maxValue">The upper limit of the range of random values to generate</param>
        /// <param name="valueSeries">The data series containing the values</param>
        /// <param name="errorSeries">The data series containing the error bars</param>
        private void GenerateDataSeries(int maxValue, out IDataSeries valueSeries, out IDataSeries errorSeries)
        {
            // A list to contain the randomly generated values
            List<double> values = new List<double>();

            // Two temporary series used while creating the data series and the error bar series
            DataSeries<double, double> tempValueSeries = new DataSeries<double, double>();
            DataSeries<double, double> tempErrorSeries = new DataSeries<double, double>();

            for (int i = 1; i <= 100; i++)
            {
                // Add the next random value to the set
                values.Add(_random.Next(maxValue));

                double mean = values.Average();

                tempValueSeries.Add(i, mean);

                // Calculate the standard error of the mean
                double error = CalculateStandardDeviation(values) / (Math.Sqrt(i));

                // Create a dictionary to store the min and max values for the error
                Dictionary<object, double> errorData = new Dictionary<object, double>()
                {
                    {ErrorBarSeries.Minimum, mean - error},
                    {ErrorBarSeries.Maximum, mean + error}
                };

                tempErrorSeries.Add(new MultiValuedDataPoint<double, double>(i, errorData));
            }

            valueSeries = tempValueSeries;
            errorSeries = tempErrorSeries;

            valueSeries.Title = String.Format("Range: 0 - {0} ", maxValue);
        }

        /// <summary>
        /// Calculates the standard deviation of the values contained in <paramref name="values"/>
        /// </summary>
        /// <param name="values">The collection of values for which to calculate the standard deviation</param>
        /// <returns>The standard deviation of the values contained in <paramref name="values"/></returns>
        private double CalculateStandardDeviation(IEnumerable<double> values)
        {
            double standardDeviation = 0;

            if (values.Count() > 0)
            {
                // Calculates the standard deviation using the formula
                // stdev(x) = sqrt(E[X^2] - (E[X])^2)
                double averageOfTheSquaredValues = values.Average(x => x * x);
                standardDeviation = Math.Sqrt(averageOfTheSquaredValues - Math.Pow(values.Average(), 2));
            }

            return standardDeviation;
        }
    }
}
