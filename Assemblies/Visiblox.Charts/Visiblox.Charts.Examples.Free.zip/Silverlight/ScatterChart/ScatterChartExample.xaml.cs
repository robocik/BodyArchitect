using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace Visiblox.Charts.Examples.ScatterChart
{
    /// <summary>
    /// An example for displaying scatter chart data
    /// </summary>
    public partial class ScatterChartExample : UserControl
    {
        /// <summary>
        /// The number of points to be displayed from each series
        /// </summary>
        private int numberOfPoints = 200;

        /// <summary>
        /// The names of each of the series to be displayed
        /// </summary>
        private string[] seriesNames = { "1500M", "10K", "Marathon" };

        /// <summary>
        /// The regular expression pattern for date of birth
        /// </summary>
        private Regex dateOfBirthPattern = new Regex("\\d{2}\\.\\d{2}.\\d{2}");

        /// <summary>
        /// The regular expression pattern for numbers
        /// </summary>
        private Regex numberPattern = new Regex("\\d+");

        public ScatterChartExample()
        {
            InitializeComponent();

            for (int distance = 0; distance < seriesNames.Length; distance++)
            {
                ScatterChart.Series[distance].DataSeries = GenerateDataSeries(seriesNames[distance]);
            }
        }

        private IDataSeries GenerateDataSeries(string distance)
        {
            var series = new DataSeries<int, int>();

            using (StreamReader reader = CreateFileReader(distance))
            {
                int numPointsRead = 0;
                // Read each line in the file
                while (reader.Peek() >= 0)
                {
                    string line = reader.ReadLine();
                    string[] parts = line.Split(new char[] { ' ', '\t' });

                    if (numberPattern.IsMatch(parts[0]))
                    {
                        int linePosition = int.Parse(parts[0]);

                        if (linePosition >= numberOfPoints - 1)
                            break;

                        foreach (String part in parts)
                        {
                            if (dateOfBirthPattern.IsMatch(part))
                            {
                                DateTime dob = GetDateOfBirth(part);
                                // Get the age of the person from the date of birth
                                int age = Convert.ToInt32(Math.Round((double)(DateTime.Now - dob).Days / 365));
                                series.Add(new DataPoint<int, int>(linePosition, age));
                                numPointsRead++;
                                break;
                            }
                        }
                    }
                }
            }

            // Set the created DataSeries to be the data source of one of the chart series
            series.Title = distance;
            return series;
        }

        /// <summary>
        /// Create the file reader based on the distance name
        /// </summary>
        private StreamReader CreateFileReader(string distance)
        {
            string filename = String.Format("ScatterChart/Data/{0}Rankings2009.txt", distance);
            return new StreamReader(ExampleHelpers.GetApplicationResourceStream(filename).Stream);
        }

        /// <summary>
        /// Convert a string representation to a date of birth
        /// </summary>
        private DateTime GetDateOfBirth(string dobString)
        {
            string[] parts = dobString.Split('.');
            return new DateTime(int.Parse(parts[2]) + 1900, int.Parse(parts[1]), int.Parse(parts[0]));
        }


        /// <summary>
        /// Toggle the series visibility
        /// </summary>
        private void Button_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            LineSeries toggleSeries = (LineSeries)ScatterChart.Series[0];

            switch (checkBox.Name)
            {
                case "FiftenHundred": toggleSeries = (LineSeries)ScatterChart.Series[0]; break;
                case "TenThousand": toggleSeries = (LineSeries)ScatterChart.Series[1]; break;
                case "Marathon": toggleSeries = (LineSeries)ScatterChart.Series[2]; break;
            }

            toggleSeries.Visibility = checkBox.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
        }
    }
}