﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace Visiblox.Charts.Examples.LogChart
{
    public partial class LogChartExample : UserControl
    {
        public LogChartExample()
        {
            InitializeComponent();
            chart.Loaded += new RoutedEventHandler(chart_Loaded);
            chart.Series[0].DataSeries = GenereateDataSeries(2);
            chart.Series[1].DataSeries = GenereateDataSeries(4);
            chart.Series[2].DataSeries = GenereateDataSeries(6);
        }

        void chart_Loaded(object sender, RoutedEventArgs e)
        {
            // Set the Logarithmic Base property of the Y Axis to be bound to the selected radio button
            (chart.YAxis as LogarithmicAxis).SetBinding(Charts.LogarithmicAxis.LogarithmicBaseProperty,
                new Binding()
                {
                    Source = YAxisBaseList,
                    Path = new PropertyPath("SelectedItem.Content.Content"),
                    Mode = BindingMode.TwoWay
                });
        }

        private IDataSeries GenereateDataSeries(int power)
        {
            DataSeries<double, double> dataSeries = new DataSeries<double, double>();
            dataSeries.Title = "f(x) = x^" + power;

            for (double x = -10; x <= 10; x += 0.25)
            {
                dataSeries.Add(x, Math.Pow(x, power));
            }

            return dataSeries;
        }
    }
}