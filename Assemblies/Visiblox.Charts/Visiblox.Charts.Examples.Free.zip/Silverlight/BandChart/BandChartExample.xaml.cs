using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Data;

namespace Visiblox.Charts.Examples.BandChart
{
    /// <summary>
    /// A simple chart example displaying band data
    /// </summary>
    public partial class BandChartExample : UserControl
    {
        private int numberOfPoints = 30;

        public BandChartExample()
        {
            InitializeComponent();
            MainChart.Series.First().DataSeries = GenerateDataSeries();
        }

        /// <summary>
        /// Load the data from the CSV file and return it as a data series
        /// </summary>
        /// <returns>The data series</returns>
        private IDataSeries GenerateDataSeries()
        {
            // Create a DataSeries to later fill up and set as data source for the candlestick series
            var series = new DataSeries<DateTime, double>();

            using (StreamReader reader = new StreamReader(ExampleHelpers.GetApplicationResourceStream("BandChart/Data/MSFT.csv").Stream))
            {
                // First line is header information, so skip before reading data
                reader.ReadLine();

                // Read in the required number of points into the dataseries
                while (reader.Peek() >= 0 && series.Count < numberOfPoints)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(',');

                    DateTime date = DateTime.Parse(values[0]);
                    double open = double.Parse(values[1]);
                    double close = double.Parse(values[4]);

                    Dictionary<object, double> data = new Dictionary<object, double>();
                    data.Add(BandSeries.Lower, open);
                    data.Add(BandSeries.Upper, close);

                    series.Add(new MultiValuedDataPoint<DateTime, double>(date, data));
                }
            }

            return series;
        }
    }

    /// <summary>
    /// Value converter to extract the relevant YValue from the data point and display it in a suitable format
    /// </summary>
    public class YValuesConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            IDataPoint dataPoint = value as IDataPoint;
            if (dataPoint != null)
            {
                return ((double)dataPoint[parameter]).ToString("N2");
            }

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
