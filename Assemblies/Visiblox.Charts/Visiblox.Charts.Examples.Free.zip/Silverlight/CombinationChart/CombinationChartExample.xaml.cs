using System.Collections.Generic;
using System.Windows.Controls;

namespace Visiblox.Charts.Examples.CombinationChart
{
    /// <summary>
    /// An example to display a combined bar and line chart modelling
    /// the number of returns of a laptop for a particular reason
    /// </summary>
    public partial class CombinationChartExample : UserControl
    {
        public CombinationChartExample()
        {
            InitializeComponent();

            GenerateDataSeries();            
        }

        private IEnumerable<Return> GenerateData()
        {
            List<Return> data = new List<Return>();

            //Create list of data
            data.Add(new Return() { Percent = 30, Reason = "Setup Issue" });
            data.Add(new Return() { Percent = 25, Reason = "Hard to Use" });
            data.Add(new Return() { Percent = 15, Reason = "Too Slow" });
            data.Add(new Return() { Percent = 15, Reason = "Too Heavy" });
            data.Add(new Return() { Percent = 10, Reason = "Wrong Manual" });
            data.Add(new Return() { Percent = 5, Reason = "No Cord" });

            return data;
        }

        public void GenerateDataSeries()
        {
            var barSeries = new DataSeries<string, double>();
            var lineSeries = new DataSeries<string, double>();

            double runningTotal = 0;

            foreach (Return dataItem in GenerateData())
            {
                //Add actual value to bar series, cumulative total to line series
                runningTotal += dataItem.Percent;
                barSeries.Add(new DataPoint<string, double>() { X = dataItem.Reason, Y = dataItem.Percent });
                lineSeries.Add(new DataPoint<string, double>() { X = dataItem.Reason, Y = runningTotal });
            }

            CombinationChart.Series[0].DataSeries = barSeries;
            CombinationChart.Series[1].DataSeries = lineSeries;
        }
    }

    // Data Model

    /// <summary>
    /// A return object
    /// </summary>
    public class Return
    {
        public double Percent { get; set; }

        public string Reason { get; set; }
    }
}
