using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Data;
using System.Xml.Linq;

namespace Visiblox.Charts.Examples.TermStructure
{
    /// <summary>
    /// An example to demonstrate multiple points with a best fit curve
    /// drawn through them with trackball behaviour
    /// </summary>
    public partial class TermStructureExample : UserControl
    {
        public TermStructureExample()
        {
            InitializeComponent();

            // Assign the first data series and the best fit curve
            TermStructureChart.Series[0].DataSeries = GenerateBindableDataSeries();
            TermStructureChart.Series[1].DataSeries = GenerateBestFitDataSeries();

            // Add the trackball onto the individual points (not the best fit curve)
            BehaviourManager behaviourManager = TermStructureChart.Behaviour as BehaviourManager;
            (behaviourManager.Behaviours[1] as TrackballBehaviour).Series.Add(TermStructureChart.Series.First());
        }

        private IDataSeries GenerateBindableDataSeries()
        {
            BindableDataSeries bindableDataSeries = new BindableDataSeries();

            bindableDataSeries.XValueBinding = new Binding("X");
            bindableDataSeries.YValueBinding = new Binding("Y");
            bindableDataSeries.ItemsSource = CreateYieldCurvePoints();

            return bindableDataSeries;
        }

        private List<YieldPoint> CreateYieldCurvePoints()
        {
            List<YieldPoint> points = new List<YieldPoint>();
            XDocument doc = XDocument.Load("TermStructure/Data/Yield.xml");
            IEnumerable<XElement> dataPoints = doc.Descendants("val");
            foreach (XElement dataPoint in dataPoints)
            {
                var xValue = Double.Parse(dataPoint.Attribute("x").Value);
                var yValue = Double.Parse(dataPoint.Attribute("y").Value);
                var instrumentName = dataPoint.Attribute("label").Value;
                points.Add(new YieldPoint(xValue, yValue, instrumentName));
            }
            return points;
        }

        private IDataSeries GenerateBestFitDataSeries()
        {
            DataSeries<double, double> curve = new DataSeries<double, double>();

            curve.Title = "Best Fit";
            curve.Add(new DataPoint<double, double>(00.00, 0.00));
            curve.Add(new DataPoint<double, double>(01.25, 0.50));
            curve.Add(new DataPoint<double, double>(02.50, 1.16));
            curve.Add(new DataPoint<double, double>(03.75, 1.80));
            curve.Add(new DataPoint<double, double>(05.00, 2.30));
            curve.Add(new DataPoint<double, double>(06.25, 2.78));
            curve.Add(new DataPoint<double, double>(07.50, 3.05));
            curve.Add(new DataPoint<double, double>(08.75, 3.35));
            curve.Add(new DataPoint<double, double>(10.00, 3.58));
            curve.Add(new DataPoint<double, double>(11.25, 3.73));
            curve.Add(new DataPoint<double, double>(12.50, 3.88));
            curve.Add(new DataPoint<double, double>(13.75, 3.95));
            curve.Add(new DataPoint<double, double>(15.00, 4.02));
            curve.Add(new DataPoint<double, double>(16.25, 4.07));
            curve.Add(new DataPoint<double, double>(17.50, 4.13));
            curve.Add(new DataPoint<double, double>(18.75, 4.20));
            curve.Add(new DataPoint<double, double>(20.00, 4.25));
            curve.Add(new DataPoint<double, double>(21.25, 4.27));
            curve.Add(new DataPoint<double, double>(22.50, 4.29));
            curve.Add(new DataPoint<double, double>(24.75, 4.30));
            curve.Add(new DataPoint<double, double>(26.00, 4.31));
            curve.Add(new DataPoint<double, double>(27.25, 4.32));
            curve.Add(new DataPoint<double, double>(28.50, 4.33));
            curve.Add(new DataPoint<double, double>(30.75, 4.34));

            return curve;
        }
    }

    // Data Model

    public class YieldPoint
    {
        public YieldPoint(double xValue, double yValue, string instrumentName)
        {
            X = xValue;
            Y = yValue;
            InstrumentName = instrumentName;
        }

        public double X { get; private set; }

        public double Y { get; private set; }

        public string InstrumentName { get; private set; }
    }
}