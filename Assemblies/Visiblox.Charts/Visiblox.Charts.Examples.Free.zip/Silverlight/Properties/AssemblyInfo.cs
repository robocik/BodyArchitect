using System.Reflection;
using System.Resources;
using System;

[assembly: AssemblyTitle("Visiblox.Charts.Examples")]
[assembly: AssemblyDescription("")]
[assembly: NeutralResourcesLanguage("en-GB")]
[assembly: CLSCompliant(true)]