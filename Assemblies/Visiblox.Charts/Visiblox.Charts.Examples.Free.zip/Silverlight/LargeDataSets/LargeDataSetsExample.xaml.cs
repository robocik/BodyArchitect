using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace Visiblox.Charts.Examples.LargeDataSets
{
    /// <summary>
    /// An example to display how the chart handles very large datasets
    /// </summary>
    public partial class LargeDataSetsExample : UserControl
    {
        /// <summary>
        /// The number of datapoints in each series
        /// </summary>
        private int numberOfDataPoints;

        private Random random = new Random(20110810);

        /// <summary>
        /// Behaviours defined in code behind as an alternative to xaml
        /// </summary>
        private ZoomBehaviour zoom = new ZoomBehaviour();
        private CrosshairBehaviour crosshair = new CrosshairBehaviour();

        /// <summary>
        /// Default constructor
        /// </summary>
        public LargeDataSetsExample()
        {
            InitializeComponent();

            // Use maximum X axis range value as number of data points to create
            numberOfDataPoints = Convert.ToInt32(LargeDataSetChart.XAxis.Range.Maximum);
            AssignDataSeries();

            // Add zoom behaviour
            ((BehaviourManager)LargeDataSetChart.Behaviour).Behaviours.Add(zoom);

            // Listen to X axis property changed events to handle custom zoom behaviour
            LargeDataSetChart.XAxis.PropertyChanged += HandleZoom;
        }

        private void AssignDataSeries()
        {
            // Generate the random data points for the series
            var series1 = new DataSeries<int, double>();
            var series2 = new DataSeries<int, double>();
            var series3 = new DataSeries<int, double>();
            var series4 = new DataSeries<int, double>();
            var series5 = new DataSeries<int, double>();
            var series6 = new DataSeries<int, double>();

            for (int i = 0; i <= numberOfDataPoints; i++)
            {
                series1.Add(CreateDataPoint(i, 1.25));
                series2.Add(CreateDataPoint(i, 2.25));
                series3.Add(CreateDataPoint(i, 3.25));
                series4.Add(CreateDataPoint(i, 4.25));
                series5.Add(CreateDataPoint(i, 5.25));
                series6.Add(CreateDataPoint(i, 6.25));
            }

            LargeDataSetChart.Series[0].DataSeries = series1;
            LargeDataSetChart.Series[1].DataSeries = series2;
            LargeDataSetChart.Series[2].DataSeries = series3;
            LargeDataSetChart.Series[3].DataSeries = series4;
            LargeDataSetChart.Series[4].DataSeries = series5;
            LargeDataSetChart.Series[5].DataSeries = series6;
        }

        private DataPoint<int, double> CreateDataPoint(int iteration, double baseValue)
        {
            return new DataPoint<int, double>(iteration, baseValue + random.NextDouble() / 2);
        }

        private void ZoomButton_Checked(object sender, RoutedEventArgs e)
        {
            if (BehaviourManager != null && BehaviourManager.Behaviours.Count > 0)
            {
                BehaviourManager.Behaviours[0] = zoom;
            }
        }

        private void CrosshairButton_Checked(object sender, RoutedEventArgs e)
        {
            BehaviourManager.Behaviours[0] = crosshair;
        }

        void HandleZoom(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Zoom")
            {
                var xAxis = LargeDataSetChart.XAxis as LinearAxis;

                //if X axis zoomed far enough, show tick interval at 2, else use default
                xAxis.MajorTickInterval = xAxis.Zoom.Scale < 0.03 ? 2 : 0;
            }
        }
    }
}