using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Visiblox.Charts.Examples.StackedAreaChart
{
    /// <summary>
    /// An example to demonstrate the ability of Visiblox to stack
    /// areas on top of each other
    /// </summary>
    public partial class StackedAreaChartExample : UserControl
    {
        public StackedAreaChartExample()
        {
            InitializeComponent();
            MainChart.YAxis.Range = new DoubleRange(0, 60);
        }

        private void Stacked_Checked(object sender, RoutedEventArgs e)
        {
            if (MainChart == null)
                return;

            var series = MainChart.Series.First() as StackedLineSeries;
            series.StackingMode = StackingMode.Normal;

            MainChart.YAxis.Range = new DoubleRange(0, 60);
            MainChart.YAxis.Title = "Sales (millions)";
        }

        private void OneHundredStacked_Checked(object sender, RoutedEventArgs e)
        {
            if (MainChart == null)
                return;

            var series = MainChart.Series.First() as StackedLineSeries;
            series.StackingMode = StackingMode.HundredPercent;

            MainChart.YAxis.Range = new DoubleRange(0, 100);
            MainChart.YAxis.Title = "Sales (%)";
        }

        private void Line_Checked(object sender, RoutedEventArgs e)
        {
            if (MainChart == null || MainChart.Series.Count < 1)
                return;

            var dataSeries = GetDataSeries();
            
            var stackedSeries = MainChart.Series.First() as StackedLineSeries;
            stackedSeries.Series.Clear();       // Clear existing

            foreach (BindableDataSeries series in dataSeries)
            {
                stackedSeries.Series.Add(new LineSeries()
                {
                    DataSeries = series,
                    SelectionMode = SelectionMode.Series,
                    ShowLine = true,
                    ShowArea = true
                });
            }
        }

        private void Spline_Checked(object sender, RoutedEventArgs e)
        {
            var dataSeries = GetDataSeries();

            var stackedSeries = MainChart.Series[0] as Visiblox.Charts.StackedLineSeries;
            stackedSeries.Series.Clear();       // Clear existing

            foreach (BindableDataSeries series in dataSeries)
            {
                stackedSeries.Series.Add(new SplineSeries()
                {
                    DataSeries = series,
                    SelectionMode = SelectionMode.Series,
                    ShowLine = true,
                    ShowArea = true
                });
            }
        }

        private List<BindableDataSeries> GetDataSeries()
        {
            var dataSeries = new List<BindableDataSeries>();

            var stackedSeries = MainChart.Series.First() as StackedLineSeries;
            foreach (IChartSingleSeries singleSeries in stackedSeries.Series)
            {
                dataSeries.Add(singleSeries.DataSeries as BindableDataSeries);
            }

            return dataSeries;
        }
    }

    // Data Model

    public class SalesList : List<Sale> { }

    public class Sale
    {
        public string Quarter { get; set; }

        public int Sales { get; set; }
    }
}
