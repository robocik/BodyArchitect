using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Visiblox.Charts.Examples.MultipleYAxes
{
    /// <summary>
    /// An example to demonstrate Visiblox support for having
    /// multiple Y axis on a single chart
    /// </summary>
    public partial class MultipleYAxesExample : UserControl
    {
        private Random random = new Random(20110810);

        private int totalData = 0;

        private bool checkDaily = false;

        private bool checkPercent = false;

        public MultipleYAxesExample()
        {
            InitializeComponent();

            //Generate daily sales data
            AxesChart.Series.First().DataSeries = GenerateDataSeries();

            //Generate cumulative % sales data
            AxesChart.Series[1].YAxis = AxesChart.SecondaryYAxis;
            AxesChart.Series[1].DataSeries = GenerateSecondaryAxisData(AxesChart.Series.First());
        }

        private IDataSeries GenerateDataSeries()
        {
            var series = new DataSeries<DateTime, double>() { Title = "Daily Sales" };

            DateTime currentDate = (DateTime)AxesChart.XAxis.Range.Minimum;
            DateTime maxDate = (DateTime)AxesChart.XAxis.Range.Maximum;
            DateTime midpointDate = new DateTime(2009, 12, 15);

            int number = random.Next(10, 20);

            while (currentDate <= maxDate)
            {

                series.Add(new DataPoint<DateTime, double>() { X = currentDate, Y = number });
                totalData += number;

                //Change sales amount to give variation on chart
                number = currentDate < midpointDate ? random.Next(10, 20) : random.Next(30, 40);
                currentDate = currentDate.AddDays(1);
            }

            return series;
        }

        private IDataSeries GenerateSecondaryAxisData(IChartSeries series)
        {
            var percentDataSeries = new DataSeries<DateTime, double>() { Title = "Total % Sales" };
            var dailyDataSeries = (DataSeries<DateTime, double>)series.DataSeries;

            double total = 0;

            //for each daily point, calculate its cumulative % of total sales
            foreach (DataPoint<DateTime, double> value in dailyDataSeries)
            {
                DateTime date = value.X;
                total += value.Y;

                double percent = total / totalData * 100;
                percentDataSeries.Add(new DataPoint<DateTime, double> { X = date, Y = percent });
            }

            return percentDataSeries;
        }

        private void dailyCheck_Checked(object sender, RoutedEventArgs e)
        {
            //only perform if chart has been created
            if (checkDaily)
            {
                LineSeries daily = (LineSeries)AxesChart.Series[0];

                //if already visible, hide series, else make it visible
                if (daily.Visibility == Visibility.Visible)
                {
                    daily.Visibility = Visibility.Collapsed;
                    (AxesChart.YAxis as LinearAxis).Visibility = Visibility.Collapsed;
                    SalesBlock.Fill = new SolidColorBrush(Colors.White);

                    //only allow one series to be hidden
                    cumulativeCheck.IsEnabled = false;
                }

                else
                {
                    daily.Visibility = Visibility.Visible;
                    (AxesChart.YAxis as LinearAxis).Visibility = Visibility.Visible;
                    SalesBlock.Fill = (AxesChart.Series[0] as LineSeries).PointFill;

                    cumulativeCheck.IsEnabled = true;
                }
            }

            checkDaily = true;
        }

        private void cumulativeCheck_Checked(object sender, RoutedEventArgs e)
        {
            //only perform is chart has been created
            if (checkPercent)
            {
                LineSeries percent = (LineSeries)AxesChart.Series[1];

                if (percent.Visibility == Visibility.Visible)
                {
                    percent.Visibility = Visibility.Collapsed;
                    (AxesChart.SecondaryYAxis as LinearAxis).Visibility = Visibility.Collapsed;
                    PercentBlock.Fill = new SolidColorBrush(Colors.White);

                    //only allow one series to be hidden
                    dailyCheck.IsEnabled = false;
                }

                else
                {
                    percent.Visibility = Visibility.Visible;
                    (AxesChart.SecondaryYAxis as LinearAxis).Visibility = Visibility.Visible;
                    PercentBlock.Fill = (AxesChart.Series[1] as LineSeries).PointFill;
                    dailyCheck.IsEnabled = true;
                }
            }

            checkPercent = true;

        }
    }
}