using System;
using System.Linq;
using System.Windows.Controls;

namespace Visiblox.Charts.Examples.AreaChart
{
    /// <summary>
    /// An example chart for displaying areas
    /// </summary>
    public partial class AreaChartExample : UserControl
    {
        private Random random = new Random(20110810);

        private DateTime startingDateTime = new DateTime(2010, 2, 18);

        public AreaChartExample()
        {
            InitializeComponent();

            // Generate data points for the series
            AreaChart.Series.First().DataSeries = GenerateDataSeries();
        }

        /// <summary>
        /// Generate the data displayed in the chart by randomly generating a 
        /// positive or negative delta to be applied to the current temperature
        /// depending on if the time is during the day or not.
        /// </summary>
        private IDataSeries GenerateDataSeries()
        {
            var series = new DataSeries<DateTime, double>();

            //Generate random temperature data for every hour on a given day
            double previousValue = 0;

            for (int i = 0; i < 24; i++)
            {
                double currentValue;
                double seed = random.NextDouble();

                bool isDayTime = i > 8 && i < 17;

                currentValue = isDayTime
                    ? previousValue + 2 * seed      // Temperature increases during the day (0800-1700)
                    : previousValue - seed;         // Decreases outwith this time

                // Add a DataPoint to the DataSeries
                series.Add(new DataPoint<DateTime, double>(startingDateTime.AddHours(i), currentValue));
                previousValue = currentValue;
            }

            return series;
        }
    }
}
